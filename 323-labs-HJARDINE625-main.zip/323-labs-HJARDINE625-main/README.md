# ECEN 323 Student Template Repository

This repository provides a template for student lab assignments. 
Students should clone this repository as decribed at the following [link](http://ecen323wiki.groups.et.byu.net/tutorials/git_setup/).


## Labs

A directory for each of the labs has been created and summarized below.

* [Lab 1](./lab01/Lab01.md)
* [Lab 2](./lab01/Lab02.md)
* [Lab 3](./lab01/Lab03.md)
* [Lab 4](./lab01/Lab04.md)
* [Lab 5](./lab01/Lab05.md)
* [Lab 6](./lab01/Lab06.md)
* [Lab 7](./lab01/Lab07.md)
* [Lab 8](./lab01/Lab08.md)
* [Lab 9](./lab01/Lab09.md)
* [Lab 10](./lab01/Lab10.md)
* [Lab 11](./lab01/Lab11.md)
* [Lab 12](./lab01/Lab12.md)
